<?php
include "./config/library.php";
include "./config/koneksi.php";

//ambil data yang didapat dari form
$id=antiinjec($koneksi, @$_REQUEST['id']);
$status=antiinjec($koneksi, @$_GET['act']);

$kode=antiinjec($koneksi, @$_POST['kode']);
$alternatif=antiinjec($koneksi, @$_POST['alternatif']);
$keterangan=antiinjec($koneksi, @$_POST['keterangan']);

if($status=="tambah" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_alternatif WHERE kode='$kode'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "INSERT INTO ft_alternatif (kode, alternatif, keterangan)
			 	 VALUES ('$kode','$alternatif','$keterangan')";
		$koneksi->query($query);
		header("location:./?page=alternatif");
	} else {
		?>
		<script language="JavaScript">alert('Kode alternatif sudah ada.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="edit" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_alternatif WHERE kode='$kode' AND id_alternatif<>'$id'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "UPDATE ft_alternatif SET 
				 kode='$kode', alternatif='$alternatif',keterangan='$keterangan'
				 where id_alternatif='$id' ";
		$koneksi->query($query);
		header("location:./?page=alternatif");
	} else {
		?>
		<script language="JavaScript">alert('Kode alternatif sudah ada.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="hapus" ) {
	$query= "DELETE FROM ft_alternatif WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	$query= "DELETE FROM ft_nilai_alternatif WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	$query= "DELETE FROM ft_nilai_alternatif_hasil WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	$query= "DELETE FROM ft_nilai_alternatif_hasil_akhir WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	$query= "DELETE FROM ft_nilai_alternatif_hasil_normal WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	$query= "DELETE FROM ft_nilai_alternatif_hasil_terbobot WHERE id_alternatif='$id' ";
	$koneksi->query($query);
	header("location:./?page=alternatif");
}

?>