<h3>Data Pengguna</h3>
<?php 
$txtcari=antiinjec($koneksi, @$_POST['txtcari']);
?>
<form method="post" action="#" enctype="multipart/form-data">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="9%">Pencarian :</td>
    <td width="14%"><input name="txtcari" type="text" size="30" value="<?php echo"$txtcari"; ?>"/></td>
    <td width="77%" style="text-align:left;"><input name="" type="submit" value="Cari" class="ok2"/></td>
  </tr>
</table>
</form>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
  	<td width="3%">No.</td>
    <td width="17%">Nama Lengkap</td>
    <td width="12%">Username</td>
    <td width="58%">Tipe</td>
	<script type="text/javascript">
    function konTambah() {
            window.location = "?page=pengguna-input&act=tambah";
    }
    </script>
    <td width="10%" align="center"><img src="images/bt_add.png" width="20" onclick="konTambah()" style="cursor:pointer;" /></td>
  </tr>
<?php
$halaman=@$_GET['halaman'];
$perhalaman=10;
$query_part ="SELECT id_pengguna, nama, username, tipe
        	  FROM ft_pengguna
			  WHERE (nama LIKE '%$txtcari%')";
$hasil_part = $koneksi->query($query_part);
$jmlhalaman_part = ceil(mysqli_num_rows($hasil_part)/$perhalaman);

if (!isset($halaman))
{
$halaman=0;
}
else
{
$halaman=$halaman-1;
}
$halamannya = $halaman * $perhalaman;

$nomor=0;
$query="SELECT id_pengguna, nama, username, tipe
        	  FROM ft_pengguna
			  WHERE (nama LIKE '%$txtcari%') ORDER BY nama ASC LIMIT $halamannya, $perhalaman" ;
$hquery=$koneksi->query($query);
while ($dataquery=mysqli_fetch_array($hquery)) {
$nomor=$nomor+1;
?>
  <tr>
  	<td><?php echo"$nomor"; ?></td>
    <td><?php echo"$dataquery[nama]"; ?></td>
    <td><?php echo"$dataquery[username]"; ?></td>
    <td>
		<?php echo""; 
			if($dataquery['tipe']==1) { echo "Administrator"; }
			elseif($dataquery['tipe']==2) { echo "Pengunjung"; }
		?>
    </td>
    <td style="text-align:center;">
	<script type="text/javascript">
    function konfirmasi<?php echo $dataquery[0]; ?>() {
        var answer = confirm("Anda yakin akan menghapus data ini?")
        if (answer){
            window.location = "aksi_pengguna.php?act=hapus&id=<?php echo"$dataquery[0]"; ?>";
        }
    }
    </script>
    <a href="?page=pengguna-input&act=edit&id=<?php echo"$dataquery[0]"; ?>">
    <img src="./images/bt_edit.png" width="20" alt="Ubah" border="0" title="Ubah Data"/>
    </a>
    <img src="./images/bt_del.png" width="20" alt="Hapus" border="0" title="Hapus Data" style="cursor:pointer;" onclick="konfirmasi<?php echo $dataquery[0]; ?>()"/>
    </td>
  </tr>
<?php
}
?>
</table>
<div id="hal">
    <div class="awal">Page's :</div> 
      <?php
        for($j=1;$j<($jmlhalaman_part+1);$j++)
        {
        ?>
        <div><a href="?page=pengguna&halaman=<?php echo"$j"; ?>" title="Halaman : <?php echo"$j"; ?>" class="<?php if (($halaman+1)==$j) { echo"pilih"; } ?>"><?php echo"$j"; ?></a></div>
        <?php }
    ?>
</div>