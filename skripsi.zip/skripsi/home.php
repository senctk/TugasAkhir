<div style="border:1px solid #E0E0E0; padding:20px; line-height:22px; font-size:14px; color:#666; font-weight:300;">
	<p>
    PT JAGAD KARYA UTAMA  adalah Developer Rumah yang terpercaya dengan nomer TDP 132516801408 dan telah terdaftar sebagai anggota Asosiasi Pengembang Perumahan dan Pemukiman Seluruh Indonesia (APERSI) dengan NIA: 04.18.0777. telah sukses membangun perumahan dengan Konsep Rumah Villa di Kabupaten Malang dan Kota Batu Bahkan di Indonesia. Kami memastikan Investasi Anda Menguntungkan, selain memiliki Rumah di tempat Strategis untuk Homestay/Liburan, Kami juga memberikan garansi sewa yang dikelola oleh D’Jagad Hospitality dan tentunya dengan Profit Sharing yang menguntungkan .
    <br />
    <img src="images/efisiensienergi.png" width="100%" style="opacity:0.5;" />
</div>