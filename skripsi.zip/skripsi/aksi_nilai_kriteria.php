<?php
include "./config/library.php";
include "./config/koneksi.php";

$responden=antiinjec($koneksi, @$_POST['responden']);
$kriteria=@$_POST['kriteria'];

//simpan jawabannya
$jml=count($kriteria);
for($j=0; $j<$jml; $j++) {
	$id=$kriteria[$j];
	$nilai=@$_POST["nilai".$id];
	if($nilai<>"" or $nilai<>0) { 
		$q_nilai="SELECT id_kriteria_bobot, bobot, nama, t1, t2, t3 FROM ft_kriteria_bobot WHERE id_kriteria_bobot='$nilai'";
		$h_nilai=$koneksi->query($q_nilai);
		$d_nilai=mysqli_fetch_array($h_nilai);
		$bobot	=$d_nilai['bobot'];
		$t1		=$d_nilai['t1'];
		$t2		=$d_nilai['t2'];
		$t3		=$d_nilai['t3'];
	} else {
		$bobot="-"; $t1=0; $t2=0; $t3=0;	
	}
	$cek_nilai=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_kriteria WHERE id_responden='$responden' AND id_kriteria='$id'"));	
	if($cek_nilai[0]==0) {
		$query="INSERT INTO ft_nilai_kriteria (id_responden, id_kriteria, id_kriteria_bobot, bobot, t1, t2, t3) 
				VALUES ('$responden', '$id', '$nilai', '$bobot', '$t1', '$t2', '$t3')";
		$koneksi->query($query);
	} else {
		$query="UPDATE ft_nilai_kriteria SET id_kriteria_bobot='$nilai', bobot='$bobot', t1='$t1', t2='$t2', t3='$t3' 
				WHERE id_responden='$responden' AND id_kriteria='$id'";
		$koneksi->query($query);
	}
	
}

?>
<script language="JavaScript">alert('Data sudah berhasil disimpan.'); document.location.href='./?page=n_kriteria&responden=<?php echo $responden; ?>'; </script>