<?php
include "./config/library.php";
include "./config/koneksi.php";

//ambil data yang didapat dari form
$id=antiinjec($koneksi, @$_REQUEST['id']);
$status=antiinjec($koneksi, @$_GET['act']);

$bobot=antiinjec($koneksi, @$_POST['bobot']);
$nama=antiinjec($koneksi, @$_POST['nama']);
$t1=antiinjec($koneksi, @$_POST['t1']);
$t2=antiinjec($koneksi, @$_POST['t2']);
$t3=antiinjec($koneksi, @$_POST['t3']);

if($status=="edit" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_kriteria_bobot WHERE bobot='$bobot' AND id_kriteria_bobot<>'$id'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "UPDATE ft_kriteria_bobot SET 
				 bobot='$bobot', nama='$nama',t1='$t1',t2='$t2',t3='$t3'
				 where id_kriteria_bobot='$id' ";
		$koneksi->query($query);
		header("location:./?page=r-kriteria");
	} else {
		?>
		<script language="JavaScript">alert('Kode bobot kriteria sudah ada.'); history.go(-1); </script>
        <?php
	}		
}

?>


