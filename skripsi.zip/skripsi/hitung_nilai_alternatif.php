<h3>Perhitungan Keputusan Alternatif</h3>
<?php 
$responden=antiinjec($koneksi, @$_REQUEST['responden']);
if($responden=="") {
  $q_res="SELECT id_responden FROM ft_responden ORDER BY id_responden ASC LIMIT 0, 1";
  $h_res=$koneksi->query($q_res);
  $d_res=mysqli_fetch_array($h_res);
  $responden=$d_res['id_responden'];
}

$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="padding:0 10px 10px 10px; border:1px solid #F60;">
<!-- TABEL KE-1 -->
<h4 style="font-size:14px; margin:10px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Nilai Keputusan Setiap Responden</h4>
<form method="post" action="#" enctype="multipart/form-data">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="9%">Responden:</td>
    <td width="3%">
    <select name="responden">
    	<?php 
		$q_res="SELECT id_responden, responden FROM ft_responden ORDER BY id_responden ASC";
		$h_res=$koneksi->query($q_res);
		while($d_res=mysqli_fetch_array($h_res)){
		?>
			<option value="<?php echo $d_res['id_responden']; ?>" <?php if($d_res['id_responden']==$responden) { echo "selected"; } ?>>
            	<?php echo $d_res['responden']; ?>
            </option>
        <?php		
		}
		?>
    </select>
    </td>
    <td width="88%" style="text-align:left;"><input name="" type="submit" value="Lihat"/></td>
  </tr>
</table>
</form>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="45" rowspan="2">Kode</td>
    <td width="684" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="<?php echo $jmlkkolom; ?>"><div style="text-align:center;">Kriteria</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="403"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_alternatif, kode, alternatif, keterangan FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif, keputusan FROM ft_nilai_alternatif WHERE id_responden='$responden' and id_kriteria='$db2[id_kriteria]' AND id_alternatif='$dquery_dinilai[id_alternatif]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		?>
        <td style="text-align:center;"><?php echo $dn['keputusan']; ?></td>
    <?php } ?>
    </tr>
<?php } ?>
</table>
</div>

<!-- TABEL KE-2 -->
<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Nilai Triangular Fuzzy Number (Sesuai Responden Terpilih &uarr;)</h4>
<?php
$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Kode</td>
    <td width="339" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Triangular Fuzzy Number</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="734" colspan="3"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_alternatif, kode, alternatif, keterangan FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif, keputusan, t1, t2, t3 FROM ft_nilai_alternatif WHERE id_responden='$responden' and id_kriteria='$db2[id_kriteria]' AND id_alternatif='$dquery_dinilai[id_alternatif]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		for($i=1; $i<=3; $i++) {
		?>
        <td style="text-align:center;"><?php echo $dn['t'.$i]; ?></td>
    <?php }} ?>
    </tr>
<?php } ?>
</table>
</div>
</div>

<!-- TABEL KE-3 -->
<?php
//Mulai Hitung Fuzzy Bobot
$query_dinilai="SELECT id_alternatif, kode, alternatif FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$q_krit="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
	$h_krit=$koneksi->query($q_krit);
	while($d_krit=mysqli_fetch_array($h_krit)){
		//Jumlah Responden
		$q_res="SELECT COUNT(*) FROM ft_responden ORDER BY id_responden ASC";
		$h_res=$koneksi->query($q_res);
		$d_res=mysqli_fetch_array($h_res);
		//Jumlah Nilai
		$q_nilai_a=mysqli_fetch_array($koneksi->query("SELECT SUM(t1) as jumlah_a FROM ft_nilai_alternatif WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		$q_nilai_b=mysqli_fetch_array($koneksi->query("SELECT SUM(t2) as jumlah_b FROM ft_nilai_alternatif WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		$q_nilai_c=mysqli_fetch_array($koneksi->query("SELECT SUM(t3) as jumlah_c FROM ft_nilai_alternatif WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		//Rata-rata
		$rata_a=$q_nilai_a['jumlah_a']/$d_res[0];
		$rata_b=$q_nilai_b['jumlah_b']/$d_res[0];
		$rata_c=$q_nilai_c['jumlah_c']/$d_res[0];
	
		$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif_hasil WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		if($d_cek[0]==0) {
			$koneksi->query("INSERT INTO ft_nilai_alternatif_hasil (id_alternatif, id_kriteria, n_a, n_b, n_c) 
					 VALUES ('$dquery_dinilai[id_alternatif]', '$d_krit[id_kriteria]', '$rata_a', '$rata_b', '$rata_c')");
		} else {
			$koneksi->query("UPDATE ft_nilai_alternatif_hasil SET n_a='$rata_a', n_b='$rata_b', n_c='$rata_c' 
					 WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'");
		}
	}
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Fuzzy Matrix Keputusan</h4>
<?php
$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Kode</td>
    <td width="339" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Fuzzy Keputusan</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="734" colspan="3"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_alternatif, kode, alternatif, keterangan FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif_hasil, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil WHERE id_alternatif='$dquery_dinilai[id_alternatif]' and id_kriteria='$db2[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		$n="";
		for($i=1; $i<=3; $i++) {
			if($i==1) { $n="a"; } elseif($i==2) { $n="b"; } elseif($i==3) { $n="c"; }
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_'.$n],3,',','.'); ?></td>
    <?php }} ?>
    </tr>
<?php } ?>
</table>
</div>

<!-- TABEL KE-4  Normalisasi Matriks -->
<?php
//Mulai Normalisasi Matriks
$q_krit="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$h_krit=$koneksi->query($q_krit);
while($d_krit=mysqli_fetch_array($h_krit)){
	
	$np_a=0; $np_b=0; $np_c=0; 
	$np_total_a=0; $np_total_b=0; $np_total_c=0;
	
	$q_pembagi="SELECT id_nilai_alternatif_hasil, id_alternatif, id_kriteria, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil WHERE id_kriteria='$d_krit[id_kriteria]'";
	$h_pembagi=$koneksi->query($q_pembagi);
	while($d_pembagi=mysqli_fetch_array($h_pembagi)) {
		//Jumlah dan pangkatkan 2 nilai untuk setiap kriteria (setiap alternatif)
		//pow=pangkat - pow(bilangan, pangkat)
		$np_a=pow($d_pembagi['n_a'], 2);
		$np_b=pow($d_pembagi['n_b'], 2);
		$np_c=pow($d_pembagi['n_c'], 2);
		$np_total_a=$np_total_a+$np_a;
		$np_total_b=$np_total_b+$np_b;
		$np_total_c=$np_total_c+$np_c;
	}
	//sqrt=akar 2 atau akar kuadrat - sqrt(4)=2
	$x_akar_a=sqrt($np_total_a);
	$x_akar_b=sqrt($np_total_b);
	$x_akar_c=sqrt($np_total_c);
	
	//Hitung nilai Normalisasi
	if($x_akar_a==0 || $x_akar_a=="") { $x_akar_a=1; }
	if($x_akar_b==0 || $x_akar_b=="") { $x_akar_b=1; }
	if($x_akar_c==0 || $x_akar_c=="") { $x_akar_c=1; }

	$q_dibagi="SELECT id_nilai_alternatif_hasil, id_alternatif, id_kriteria, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil WHERE id_kriteria='$d_krit[id_kriteria]'";
	$h_dibagi=$koneksi->query($q_dibagi);
	while($d_dibagi=mysqli_fetch_array($h_dibagi)) {
		//Nilai Normalisasi
		$R_a=$d_dibagi['n_a']/$x_akar_a;
		$R_b=$d_dibagi['n_b']/$x_akar_b;
		$R_c=$d_dibagi['n_c']/$x_akar_c;
		//Simpan hasil normalisasi
		$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif_hasil_normal WHERE id_alternatif='$d_dibagi[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		if($d_cek[0]==0) {
			$koneksi->query("INSERT INTO ft_nilai_alternatif_hasil_normal (id_alternatif, id_kriteria, n_a, n_b, n_c) 
					 VALUES ('$d_dibagi[id_alternatif]', '$d_krit[id_kriteria]', '$R_a', '$R_b', '$R_c')");
		} else {
			$koneksi->query("UPDATE ft_nilai_alternatif_hasil_normal SET n_a='$R_a', n_b='$R_b', n_c='$R_c' 
					 WHERE id_alternatif='$d_dibagi[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'");
		}
		
	}
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Matriks Keputusan Ternormalisasi</h4>
<?php
$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Kode</td>
    <td width="339" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Nilai Normalisasi</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="734" colspan="3"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_alternatif, kode, alternatif, keterangan FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif_hasil_normal, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil_normal WHERE id_alternatif='$dquery_dinilai[id_alternatif]' and id_kriteria='$db2[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		$n="";
		for($i=1; $i<=3; $i++) {
			if($i==1) { $n="a"; } elseif($i==2) { $n="b"; } elseif($i==3) { $n="c"; }
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_'.$n],3,',','.'); ?></td>
    <?php }} ?>
    </tr>
<?php } ?>
</table>
</div>

<!-- TABEL KE-5 ############ Normalisasi Matriks Terbobot -->
<?php
//Mulai Normalisasi Matriks
$q_krit="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$h_krit=$koneksi->query($q_krit);
while($d_krit=mysqli_fetch_array($h_krit)){
	
	$q_dibagi="SELECT id_nilai_alternatif_hasil_normal, id_alternatif, id_kriteria, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil_normal WHERE id_kriteria='$d_krit[id_kriteria]'";
	$h_dibagi=$koneksi->query($q_dibagi);
	while($d_dibagi=mysqli_fetch_array($h_dibagi)) {

		//Ambil Bobot
		$q_bobot="SELECT id_nilai_kriteria_hasil, id_kriteria, n_a, n_b, n_c FROM ft_nilai_kriteria_hasil WHERE id_kriteria='$d_krit[id_kriteria]'";
		$h_bobot=$koneksi->query($q_bobot);
		$d_bobot=mysqli_fetch_array($h_bobot);
		
		//Hitung Normalisasi * bobot
		$nbobot_a=$d_dibagi['n_a']*$d_bobot['n_a'];
		$nbobot_b=$d_dibagi['n_b']*$d_bobot['n_b'];
		$nbobot_c=$d_dibagi['n_c']*$d_bobot['n_c'];

		//Simpan hasil normalisasi terbobot
		$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif_hasil_terbobot WHERE id_alternatif='$d_dibagi[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'"));
		if($d_cek[0]==0) {
			$koneksi->query("INSERT INTO ft_nilai_alternatif_hasil_terbobot (id_alternatif, id_kriteria, n_a, n_b, n_c) 
					 VALUES ('$d_dibagi[id_alternatif]', '$d_krit[id_kriteria]', '$nbobot_a', '$nbobot_b', '$nbobot_c')");
		} else {
			$koneksi->query("UPDATE ft_nilai_alternatif_hasil_terbobot SET n_a='$nbobot_a', n_b='$nbobot_b', n_c='$nbobot_c' 
					 WHERE id_alternatif='$d_dibagi[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'");
		}
		
	}
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Matriks Keputusan Ternormalisasi Terbobot</h4>
<?php
$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Kode</td>
    <td width="339" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Nilai Normalisasi</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="734" colspan="3"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_alternatif, kode, alternatif, keterangan FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif_hasil_terbobot, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil_terbobot WHERE id_alternatif='$dquery_dinilai[id_alternatif]' and id_kriteria='$db2[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		$n="";
		for($i=1; $i<=3; $i++) {
			if($i==1) { $n="a"; } elseif($i==2) { $n="b"; } elseif($i==3) { $n="c"; }
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_'.$n],3,',','.'); ?></td>
    <?php }} ?>
    </tr>
<?php } ?>
</table>
</div>

<!-- TABEL KE-6 ############ Solusi Ideal -->
<?php
//Mulai Normalisasi Matriks
$q_krit="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$h_krit=$koneksi->query($q_krit);
while($d_krit=mysqli_fetch_array($h_krit)){
	
	$q_dibagi="SELECT id_nilai_alternatif_hasil_terbobot, max(n_a) as max_a, max(n_b) as max_b, max(n_c) as max_c, 
					  min(n_a) as min_a, min(n_b) as min_b, min(n_c) as min_c  
			   FROM ft_nilai_alternatif_hasil_terbobot WHERE id_kriteria='$d_krit[id_kriteria]'";
	$h_dibagi=$koneksi->query($q_dibagi);
	$d_dibagi=mysqli_fetch_array($h_dibagi);

	//Simpan hasil normalisasi terbobot
	$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif_hasil_solusi_ideal WHERE id_kriteria='$d_krit[id_kriteria]'"));
	if($d_cek[0]==0) {
		$koneksi->query("INSERT INTO ft_nilai_alternatif_hasil_solusi_ideal (id_kriteria, n_a, n_b, n_c, n_a_min, n_b_min, n_c_min) 
				 VALUES ('$d_krit[id_kriteria]', '$d_dibagi[max_a]', '$d_dibagi[max_b]', '$d_dibagi[max_c]', '$d_dibagi[min_a]', '$d_dibagi[min_b]', '$d_dibagi[min_c]')");
	} else {
		$koneksi->query("UPDATE ft_nilai_alternatif_hasil_solusi_ideal 
				 SET n_a='$d_dibagi[max_a]', n_b='$d_dibagi[max_b]', n_c='$d_dibagi[max_c]', n_a_min='$d_dibagi[min_a]', n_b_min='$d_dibagi[min_b]', n_c_min='$d_dibagi[min_c]' 
				 WHERE id_kriteria='$d_krit[id_kriteria]'");
	}
	
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Solusi Ideal</h4>
<?php
$qb="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Solusi Ideal</td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Nilai Solusi Ideal</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="734" colspan="3"><div style="text-align:center;"><?php echo "$db[kode]"; ?></div></td>
    <?php } ?>
  </tr>

  <tr>
    <td>1</td>
    <td>FPIS</td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif_hasil_solusi_ideal, n_a, n_b, n_c FROM ft_nilai_alternatif_hasil_solusi_ideal WHERE id_kriteria='$db2[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		$n="";
		for($i=1; $i<=3; $i++) {
			if($i==1) { $n="a"; } elseif($i==2) { $n="b"; } elseif($i==3) { $n="c"; }
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_'.$n],3,',','.'); ?></td>
    <?php }} ?>
    </tr>
    
  <tr>
    <td>2</td>
    <td>FNIS</td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_alternatif_hasil_solusi_ideal, n_a_min, n_b_min, n_c_min FROM ft_nilai_alternatif_hasil_solusi_ideal WHERE id_kriteria='$db2[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		$n="";
		for($i=1; $i<=3; $i++) {
			if($i==1) { $n="a_min"; } elseif($i==2) { $n="b_min"; } elseif($i==3) { $n="c_min"; }
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_'.$n],3,',','.'); ?></td>
    <?php }} ?>
    </tr>
</table>
</div>

<!-- TABEL KE-7 ############ Jarak -->
<?php
//Mulai Hitung Jarak
$query_dinilai="SELECT id_alternatif, kode, alternatif FROM ft_alternatif ORDER BY id_alternatif ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	
	$sum_plus=0; $sum_min=0;
	
	$q_krit="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
	$h_krit=$koneksi->query($q_krit);
	while($d_krit=mysqli_fetch_array($h_krit)){
		
		//Ambil nilai terbobot
		$q_terbobot="SELECT n_a, n_b, n_c FROM ft_nilai_alternatif_hasil_terbobot WHERE id_alternatif='$dquery_dinilai[id_alternatif]' AND id_kriteria='$d_krit[id_kriteria]'";
		$h_terbobot=$koneksi->query($q_terbobot);
		$d_terbobot=mysqli_fetch_array($h_terbobot);
		
		//Ambil solusi ideal
		$q_solusi="SELECT id_nilai_alternatif_hasil_solusi_ideal, n_a, n_b, n_c, n_a_min, n_b_min, n_c_min FROM ft_nilai_alternatif_hasil_solusi_ideal WHERE id_kriteria='$d_krit[id_kriteria]'";
		$h_solusi=$koneksi->query($q_solusi);
		$d_solusi=mysqli_fetch_array($h_solusi);
		
		$sum_plus=$sum_plus+((pow(($d_terbobot['n_a']-$d_solusi['n_a']), 2)+pow(($d_terbobot['n_b']-$d_solusi['n_b']), 2)+pow(($d_terbobot['n_c']-$d_solusi['n_c']), 2))/3);
		$sum_min=$sum_min+((pow(($d_terbobot['n_a']-$d_solusi['n_a_min']), 2)+pow(($d_terbobot['n_b']-$d_solusi['n_b_min']), 2)+pow(($d_terbobot['n_c']-$d_solusi['n_c_min']), 2))/3);
	}
	
	$sum_plus=sqrt($sum_plus);
	$sum_min=sqrt($sum_min);
	$n_cc=$sum_min/($sum_plus+$sum_min);
	
	$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif_hasil_akhir WHERE id_alternatif='$dquery_dinilai[id_alternatif]'"));
	if($d_cek[0]==0) {
		$koneksi->query("INSERT INTO ft_nilai_alternatif_hasil_akhir (id_alternatif, d_plus, d_min, cc) 
				 VALUES ('$dquery_dinilai[id_alternatif]', '$sum_plus', '$sum_min', '$n_cc')");
	} else {
		$koneksi->query("UPDATE ft_nilai_alternatif_hasil_akhir SET d_plus='$sum_plus', d_min='$sum_min', cc='$n_cc'
				 WHERE id_alternatif='$dquery_dinilai[id_alternatif]'");
	}
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Jarak Nilai Kriteria dengan Solusi Ideal Positif dan Negatif dan Hasil Akhir</h4>
<div style="overflow:auto;">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="37" rowspan="2">Kode</td>
    <td width="339" rowspan="2"><div style="width:150px;">Alternatif</div></td>
    <td colspan="3"><div style="text-align:center;">Nilai Akhir</div></td>
  </tr>
  <tr>
    <td><div style="text-align:center;">Jarak Solusi Ideal Positif (d+)</div></td>
    <td><div style="text-align:center;">Jarak Solusi Ideal Negatif (d-)</div></td>
    <td><div style="text-align:center; color:#F30;">Nilai Preferensi (CC)</div></td>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT a.id_alternatif, a.kode, a.alternatif, a.keterangan, b.d_plus, b.d_min, b.cc FROM ft_alternatif as a, ft_nilai_alternatif_hasil_akhir as b 
				WHERE a.id_alternatif=b.id_alternatif
				ORDER BY b.cc DESC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[alternatif]"; ?></td>
    <td><?php echo number_format($dquery_dinilai['d_plus'],6,',','.'); ?></td>
    <td><?php echo number_format($dquery_dinilai['d_min'],6,',','.'); ?></td>
    <td><span style="color:#F30; font-weight:bold;"><?php echo number_format($dquery_dinilai['cc'],6,',','.'); ?></span></td>
  </tr>
<?php } ?>
</table>
</div>
