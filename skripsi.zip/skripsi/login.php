<?php
include "./config/koneksi.php";
$err = @$_GET['err'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>PT Jagad Karya Utama</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <link rel="stylesheet" type="text/css" href="css/login.css">
</head>

<body>
    <?php if ($err != "") { ?>
        <div class="notice">
            <!--<a href="" class="close">close</a>-->
            <p class="warn">Username atau password yang Anda masukkan salah.</p>
        </div>
    <?php } ?>
    <!-- Primary Page Layout -->
    <img class="wave" src="">
    <div class="container">
        <div class="img">
            <img src="images/1.webp">
        </div>
        <div class="login-content">
            <form action="login_periksa.php" method="post">
                <img src="images/photo animasi.jpg">
                <h2 class="title">Welcome</h2>
                <div class="input-div one">
                    <div class="i">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="div">
                        <h5>Username</h5>
                        <input type="text" class="input" name="username" autofocus autocomplete="off">
                    </div>
                </div>
                <div class="input-div pass">
                    <div class="i">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="div">
                        <h5>Password</h5>
                        <input type="password" class="input" name="pass">
                    </div>
                </div>
                <label for="remember">
                </label>
                <a href="#">Forgot Password?</a>
                <button class="btn" type="Login" color="#ff0055">Masuk</button>
            </form>
        </div>
    </div>

    <script type="text/javascript" src="js/login.js"></script>

</body>

</html>