<?php
include "./config/library.php";
include "./config/koneksi.php";

$page=@$_GET['page'];
$ses_nama_pengguna=@$_SESSION['ses_nama_pengguna'];
if($ses_nama_pengguna=="")
{ 
	header("location:login.php");
} else { 
	$queryadm="SELECT * FROM ft_pengguna WHERE username='$ses_nama_pengguna'";
	$hasiladm=$koneksi->query($queryadm);
	$dataadm=mysqli_fetch_array($hasiladm);
	
	if($dataadm['tipe']==1) { $tipe_pengguna="Administrator"; }
	elseif($dataadm['tipe']==2) { $tipe_pengguna="Pengunjung"; }
?>
<!DOCTYPE html>
<title>PT Jagad Karya Utama</title>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="css/style_menu.css" type="text/css" />
<script src="js/jquery-latest.min.js" type="text/javascript"></script>
<script src="js/script.js"></script>

</head>
<body>
<div class="content">
<div class="border_round">
	<div id="status_login">
    	Selamat Datang <?php echo $dataadm['nama']." [".$tipe_pengguna; ?>]
        <?php if($dataadm['tipe']==1) { ?>  
    	<a href="index.php?page=ubah-password">Ubah Password</a> |<?php } ?> <a href="logout.php">Logout?</a> 
        
    </div>
 	<div id="atas"><span style="color:#FFF;">Sistem Pendukung Keputusan Penilaian Pelatihan Kinerja Karyawan METODE</span> <span style="background-color:#FFF; padding-left:10px; padding-right:10px;">FUZZY TOPSIS</span></div>
    <div id="menu">
        <div id='cssmenu'>
        <ul>
           <li class='<?php if($page=="") { echo 'active'; } ?>'><a href='?'>Beranda</a></li>
		   <?php if($dataadm['tipe']==1) { ?>
           <li class='<?php if($page=="kriteria" || $page=="kriteria-input") { echo 'active'; } ?>'><a href='?page=kriteria'>Data Kriteria</a></li>
           <li class='<?php if($page=="alternatif" || $page=="alternatif-input") { echo 'active'; } ?>'><a href='?page=alternatif'>Data Alternatif</a></li>
           <li class='<?php if($page=="responden" || $page=="responden-input") { echo 'active'; } ?>'><a href='?page=responden'>Data Responden</a></li>
           <li class='<?php if($page=="n_kriteria" || $page=="n_alternatif") { echo 'active'; } ?> has-sub'><a href='#'>Data Penilaian</a>
              <ul>
                 <li><a href='?page=n_kriteria'>Penilaian Kriteria</a></li>
                 <li><a href='?page=n_alternatif'>Penilaian Alternatif</a></li>
              </ul>
           </li>
           <?php } ?>
           <li class='<?php if($page=="h_kriteria" || $page=="h_alternatif") { echo 'active'; } ?> has-sub'><a href='#'>Data Perhitungan</a>
              <ul>
                 <li><a href='?page=h_kriteria'>Perhitungan Kriteria</a></li>
                 <li><a href='?page=h_alternatif'>Perhitung. Alternatif</a></li>
              </ul>
           </li>
		   <?php if($dataadm['tipe']==1) { ?>
           <li class='<?php if($page=="r-kriteria" || $page=="r-alternatif") { echo 'active'; } ?> has-sub'><a href='#'>Data Aturan</a>
              <ul>
                 <li><a href='?page=r-kriteria'>Bobot Kriteria</a></li>
                 <li><a href='?page=r-alternatif'>Keputusan Alternatif</a></li>
              </ul>
           </li>
		   <?php } if($dataadm['tipe']==1) { ?>
           <li class='<?php if($page=="pengguna" || $page=="pengguna-input") { echo 'active'; } ?>'><a href='?page=pengguna'>Data Pengguna</a></li>
           <?php } ?>
        </ul>
        </div>
    </div>
    <div id="isi">
    	<div class="garis-atas"></div>
        <div class="csstable">
    	<?php
			if($page=="kriteria" && $dataadm['tipe']==1){ include "data_kriteria.php"; } //ok
			elseif($page=="kriteria-input" && $dataadm['tipe']==1){ include "input_kriteria.php"; } //ok
			elseif($page=="alternatif" && $dataadm['tipe']==1){ include "data_alternatif.php"; } //ok
			elseif($page=="alternatif-input" && $dataadm['tipe']==1){ include "input_alternatif.php"; } //ok
			elseif($page=="responden" && $dataadm['tipe']==1){ include "data_responden.php"; } //ok
			elseif($page=="responden-input" && $dataadm['tipe']==1){ include "input_responden.php"; } //ok
			elseif($page=="n_kriteria" && $dataadm['tipe']==1){ include "data_nilai_kriteria.php"; } //ok
			elseif($page=="n_alternatif" && $dataadm['tipe']==1){ include "data_nilai_alternatif.php"; } //ok
			elseif($page=="h_kriteria"){ include "hitung_nilai_kriteria.php"; } //ok
			elseif($page=="h_alternatif"){ include "hitung_nilai_alternatif.php"; } //ok
			elseif($page=="r-kriteria" && $dataadm['tipe']==1){ include "data_bobot_kriteria.php"; } //ok
			elseif($page=="r-kriteria-input" && $dataadm['tipe']==1){ include "input_bobot_kriteria.php"; } //ok
			elseif($page=="r-alternatif" && $dataadm['tipe']==1){ include "data_keputusan_alternatif.php"; } //ok
			elseif($page=="r-alternatif-input" && $dataadm['tipe']==1){ include "input_keputusan_alternatif.php"; } //ok
			elseif($page=="pengguna" && $dataadm['tipe']==1){ include "data_pengguna.php"; } //ok
			elseif($page=="pengguna-input" && $dataadm['tipe']==1){ include "input_pengguna.php"; } //ok
			elseif($page=="ubah-password" && $dataadm['tipe']==1){ include "set_password.php"; }
			else { include "home.php"; }
		?>
        </div>
     	<div class="space"></div>
    </div>
    <div id="bawah">
        <p class="tagline_left">Sistem Pendukung Keputusan Penilaian Pelatihan Kinerja Karyawan | Dibuat oleh <a href="http://anindyadev.com/" target="_blank">Nesa Itfirul lail - 2041720004</a></p>
        <br class="clear" />
    </div>
</div>
</div>
</body>
</html>
<?php } ?>