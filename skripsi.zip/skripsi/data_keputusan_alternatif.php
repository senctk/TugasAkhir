<h3>Data Keputusan ALternatif</h3>
<table width="100%" border="0" cellpadding="0" cellspacing="0" >
  <tr>
  	<td width="2%">No.</td>
    <td width="7%">Keputusan</td>
    <td width="39%">Kepanjangan</td>
    <td width="8%" style="text-align:left;">Nilai 1</td>
    <td width="8%" style="text-align:left;">Nilai 2</td>
    <td width="34%" style="text-align:left;">Nilai 3</td>
    <td width="2%" align="center"></td>
  </tr>
<?php
$nomor=0;
$query="SELECT id_alternatif_keputusan, keputusan, nama, t1, t2, t3 FROM ft_alternatif_keputusan
	    ORDER BY id_alternatif_keputusan ASC" ;
$hquery=$koneksi->query($query);
while ($dataquery=mysqli_fetch_array($hquery)) {
$nomor=$nomor+1;
?>
  <tr>
  	<td><?php echo"$nomor"; ?></td>
    <td><?php echo"$dataquery[keputusan]"; ?></td>
    <td><?php echo"$dataquery[nama]"; ?></td>
    <td><?php echo"$dataquery[t1]"; ?></td>
    <td><?php echo"$dataquery[t2]"; ?></td>
    <td><?php echo"$dataquery[t3]"; ?></td>
    <td style="text-align:center;">
    <a href="?page=r-alternatif-input&act=edit&id=<?php echo"$dataquery[0]"; ?>">
    <img src="./images/bt_edit.png" width="20" alt="Ubah" border="0" title="Ubah Data"/>
    </a>
    </td>
  </tr>
<?php
}
?>
</table>