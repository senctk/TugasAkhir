<?php
include "./config/library.php";
include "./config/koneksi.php";

$responden=antiinjec($koneksi, @$_POST['responden']);
$kriteria=antiinjec($koneksi, @$_POST['kriteria']);
$alternatif=@$_POST['alternatif'];

//simpan jawabannya
$jml=count($alternatif);
for($j=0; $j<$jml; $j++) {
	$id=$alternatif[$j];
	$nilai=@$_POST["nilai".$id];
	if($nilai<>"" or $nilai<>0) { 
		$q_nilai="SELECT id_alternatif_keputusan, keputusan, nama, t1, t2, t3 FROM ft_alternatif_keputusan WHERE id_alternatif_keputusan='$nilai'";
		$h_nilai=$koneksi->query($q_nilai);
		$d_nilai=mysqli_fetch_array($h_nilai);
		$keputusan	=$d_nilai['keputusan'];
		$t1		=$d_nilai['t1'];
		$t2		=$d_nilai['t2'];
		$t3		=$d_nilai['t3'];
	} else {
		$keputusan="-"; $t1=0; $t2=0; $t3=0;	
	}
	$cek_nilai=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_alternatif WHERE id_responden='$responden' AND id_alternatif='$id' AND id_kriteria='$kriteria'"));	
	if($cek_nilai[0]==0) {
		$query="INSERT INTO ft_nilai_alternatif (id_responden, id_alternatif, id_kriteria, id_alternatif_keputusan, keputusan, t1, t2, t3) 
				VALUES ('$responden', '$id', '$kriteria', '$nilai', '$keputusan', '$t1', '$t2', '$t3')";
		$koneksi->query($query);
	} else {
		$query="UPDATE ft_nilai_alternatif SET id_alternatif_keputusan='$nilai', keputusan='$keputusan', t1='$t1', t2='$t2', t3='$t3' 
				WHERE id_responden='$responden' AND id_alternatif='$id' AND id_kriteria='$kriteria'";
		$koneksi->query($query);
	}
	
}

?>
<script language="JavaScript">alert('Data sudah berhasil disimpan.'); document.location.href='./?page=n_alternatif&responden=<?php echo $responden; ?>&kriteria=<?php echo $kriteria; ?>'; </script>