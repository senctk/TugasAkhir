<script type='text/javascript' src='./js/jquery.min.js?ver=3.1.2'></script>
<script type="text/javascript" src="./js/custom.js"></script>
<script type="text/javascript" src="./js/jquery.validate.js"></script>

<script type="text/javascript">
// Forms Validator
$j(function() {
   $j("#form1").validate();
});
</script>

<?php
$status=antiinjec($koneksi, @$_GET['act']);

if ($status=="edit") { $id=antiinjec($koneksi, @$_REQUEST['id']); }
if ($status=="tambah") { $id=0; }
	$query="select id_alternatif, kode, alternatif, keterangan from ft_alternatif where id_alternatif='$id'" ;
	$hquery=$koneksi->query($query);
	$dataquery=mysqli_fetch_array($hquery);
?>
<h3><?php if($status=="edit") { echo "Ubah"; } elseif ($status=="tambah") { echo "Tambah"; } ?> Data Alternatif</h3>
<form action="aksi_alternatif.php?act=<?php echo"$status"; ?>" method="post" enctype="multipart/form-data" id="form1">
<table width="100%" cellpadding="10" cellspacing="0" border="0">
  <input type="hidden" name="id" value="<?php echo @$dataquery['id_alternatif']; ?>" />
  <tr>
    <td colspan="3">Isikan data dengan benar</td>
  </tr>
  <tr>
    <td width="16%">Kode</td>
    <td width="2%">:</td>
    <td width="82%"><input name="kode" type="text" size="10" maxlength="5" value="<?php echo @$dataquery['kode']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Alternatif</td>
    <td width="2%">:</td>
    <td width="82%"><input name="alternatif" type="text" size="50" maxlength="50" value="<?php echo @$dataquery['alternatif']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Keterangan</td>
    <td width="2%">:</td>
    <td width="82%"><textarea name="keterangan" cols="50" rows="5"><?php echo @$dataquery['keterangan']; ?></textarea></td>
  </tr>
  <tr>
    <td colspan="3"><input name="simpan" type="submit" value="Simpan" class="ok"></td>
  </tr>
</table>
</form>