<?php
include "./config/library.php";
include "./config/koneksi.php";

//ambil data yang didapat dari form
$id=antiinjec($koneksi, @$_REQUEST['id']);
$status=antiinjec($koneksi, @$_GET['act']);

$kode=antiinjec($koneksi, @$_POST['kode']);
$kriteria=antiinjec($koneksi, @$_POST['kriteria']);
$atribut=antiinjec($koneksi, @$_POST['atribut']);
$keterangan=antiinjec($koneksi, @$_POST['keterangan']);

if($status=="tambah" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_kriteria WHERE kode='$kode'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "INSERT INTO ft_kriteria (kode, kriteria, implikasi, keterangan)
			 	 VALUES ('$kode','$kriteria','$atribut','$keterangan')";
		$koneksi->query($query);
		header("location:./?page=kriteria");
	} else {
		?>
		<script language="JavaScript">alert('Kode kriteria sudah ada.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="edit" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_kriteria WHERE kode='$kode' AND id_kriteria<>'$id'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "UPDATE ft_kriteria SET 
				 kode='$kode', kriteria='$kriteria',implikasi='$atribut',keterangan='$keterangan'
				 where id_kriteria='$id' ";
		$koneksi->query($query);
		header("location:./?page=kriteria");
	} else {
		?>
		<script language="JavaScript">alert('Kode kriteria sudah ada.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="hapus" ) {
	$query= "DELETE FROM ft_kriteria WHERE id_kriteria='$id' ";
	$koneksi->query($query);
	header("location:./?page=kriteria");
}

?>


