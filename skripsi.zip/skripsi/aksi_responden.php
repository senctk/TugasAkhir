<?php
include "./config/library.php";
include "./config/koneksi.php";

//ambil data yang didapat dari form
$id=antiinjec($koneksi, @$_REQUEST['id']);
$status=antiinjec($koneksi, @$_GET['act']);

$responden=antiinjec($koneksi, @$_POST['responden']);
$keterangan=antiinjec($koneksi, @$_POST['keterangan']);
$tgl=date("Y-m-d");

if($status=="tambah" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_responden WHERE responden='$responden'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "INSERT INTO ft_responden (responden, keterangan, tanggal)
			 	 VALUES ('$responden','$keterangan','$tgl')";
		$koneksi->query($query);
		header("location:./?page=responden");
	} else {
		?>
		<script language="JavaScript">alert('Responden sudah terdaftar.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="edit" ) {
	$qcek = "SELECT count(*) as jumlah FROM ft_responden WHERE responden='$responden' AND id_responden<>'$id'";
	$hcek = $koneksi->query($qcek);
	$dcek = mysqli_fetch_array($hcek);
	if($dcek[0]==0) {
		$query= "UPDATE ft_responden SET 
				 responden='$responden',keterangan='$keterangan'
				 where id_responden='$id' ";
		$koneksi->query($query);
		header("location:./?page=responden");
	} else {
		?>
		<script language="JavaScript">alert('Responden sudah terdaftar.'); history.go(-1); </script>
        <?php
	}		
}
elseif($status=="hapus" ) {
	$query= "DELETE FROM ft_responden WHERE id_responden='$id' ";
	$koneksi->query($query);
	header("location:./?page=responden");
}

?>


