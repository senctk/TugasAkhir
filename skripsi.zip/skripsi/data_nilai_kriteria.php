<h3>Data Nilai Kriteria</h3>
Halaman ini untuk melihat data pembobotan  kriteria yang telah diinputkan, dan juga digunakan untuk mengubah atau menambahkan bobot kriteria.<br><br>
<?php 
$responden=antiinjec($koneksi, @$_REQUEST['responden']);
$stat=antiinjec($koneksi, @$_REQUEST['stat']);
?>
<form method="post" action="#" enctype="multipart/form-data">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="9%">Responden:</td>
    <td width="3%">
    <select name="responden">
    	<?php 
		$q_res="SELECT id_responden, responden FROM ft_responden ORDER BY id_responden ASC";
		$h_res=$koneksi->query($q_res);
		while($d_res=mysqli_fetch_array($h_res)){
		?>
			<option value="<?php echo $d_res['id_responden']; ?>" <?php if($d_res['id_responden']==$responden) { echo "selected"; } ?>>
            	<?php echo $d_res['responden']; ?>
            </option>
        <?php		
		}
		?>
    </select>
    </td>
    <td width="88%" style="text-align:left;"><input name="" type="submit" value="Lihat"/></td>
  </tr>
</table>
</form>

<?php
if($responden=="") {
  $q_res="SELECT id_responden FROM ft_responden ORDER BY id_responden ASC LIMIT 0, 1";
  $h_res=$koneksi->query($q_res);
  $d_res=mysqli_fetch_array($h_res);
  $responden=$d_res['id_responden'];
}

$qb="SELECT id_kriteria_bobot, bobot, nama, t1, t2, t3 FROM ft_kriteria_bobot";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<style>
input[type="radio"] {
  display: none;
}

input[type="radio"] + label {
  color: #292321;
  font-family: Arial, sans-serif;
  font-size: 14px;
}

input[type="radio"] + label span {
  display: inline-block;
  width: 19px;
  height: 19px;
  margin: -1px 4px 0 0;
  vertical-align: middle;
  cursor: pointer;
  -moz-border-radius: 50%;
  border-radius: 50%;
}

input[type="radio"] + label span {
  background-color: #CCCCCC;
  border:1px solid #999;
}

input[type="radio"]:checked + label span {
  background-color: #CC3300;
  border:1px solid #C00;
}

input[type="radio"] + label span,
input[type="radio"]:checked + label span {
  -webkit-transition: background-color 0.4s linear;
  -o-transition: background-color 0.4s linear;
  -moz-transition: background-color 0.4s linear;
  transition: background-color 0.4s linear;
}
</style>
<div class="test2">
<form action="aksi_nilai_kriteria.php" method="post" enctype="multipart/form-data" id="form1">
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="78" rowspan="2">Kode</td>
    <td width="761" rowspan="2">Kriteria</td>
    <td colspan="<?php echo $jmlkkolom; ?>"><div style="text-align:center;">Pilihan Bobot</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="293"><div style="text-align:center;"><?php echo "$db[bobot]"; ?><br /><?php echo "$db[nama]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <input type="hidden" name="kriteria[]" value="<?php echo $dquery_dinilai['id_kriteria']; ?>" />
  <input type="hidden" name="responden" value="<?php echo $responden; ?>" />
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[kriteria]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_kriteria_bobot, bobot, nama, t1, t2, t3 FROM ft_kriteria_bobot";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_kriteria_bobot, bobot FROM ft_nilai_kriteria WHERE id_responden='$responden' AND bobot='$db2[bobot]' and id_kriteria='$dquery_dinilai[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		?>
        <td style="text-align:center;">
            <div>
              <input type="radio" id="radio0<?php echo @$dquery_dinilai['id_kriteria'].@$db2[0]; ?>" name="nilai<?php echo @$dquery_dinilai['id_kriteria']; ?>" value="<?php echo @$db2['id_kriteria_bobot']; ?>" <?php if(@$dn['id_kriteria_bobot']==@$db2['id_kriteria_bobot']) { echo "checked"; } ?>/>
              <label for="radio0<?php echo @$dquery_dinilai['id_kriteria'].@$db2[0]; ?>"><span></span></label>
            </div>
        </td>
    <?php } ?>
    </tr>
<?php } ?>
    <tr>
      <td>&nbsp;</td>
      <td colspan="<?php echo 3+$jmlkkolom; ?>">
      <input type="submit" name="btn_simpan" value="Simpan">
      </td>
    </tr>
</table>
</form>
</div>