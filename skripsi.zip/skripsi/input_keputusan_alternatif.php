<script type='text/javascript' src='./js/jquery.min.js?ver=3.1.2'></script>
<script type="text/javascript" src="./js/custom.js"></script>
<script type="text/javascript" src="./js/jquery.validate.js"></script>

<script type="text/javascript">
// Forms Validator
$j(function() {
   $j("#form1").validate();
});
</script>

<?php
$status=antiinjec($koneksi, @$_GET['act']);

if ($status=="edit") { $id=antiinjec($koneksi, @$_REQUEST['id']); }
$query="select id_alternatif_keputusan, keputusan, nama, t1, t2, t3 FROM ft_alternatif_keputusan where id_alternatif_keputusan='$id'" ;
$hquery=$koneksi->query($query);
$dataquery=mysqli_fetch_array($hquery);
?>
<h3><?php if($status=="edit") { echo "Ubah"; } elseif ($status=="tambah") { echo "Tambah"; } ?> Data Keputusan Alternatif</h3>
<form action="aksi_keputusan_alternatif.php?act=<?php echo"$status"; ?>" method="post" enctype="multipart/form-data" id="form1">
<table width="100%" cellpadding="10" cellspacing="0" border="0">
  <input type="hidden" name="id" value="<?php echo @$dataquery['id_alternatif_keputusan']; ?>" />
  <tr>
    <td colspan="3">Isikan data dengan benar</td>
  </tr>
  <tr>
    <td width="16%">Keputusan</td>
    <td width="2%">:</td>
    <td width="82%"><input name="keputusan" type="text" size="10" maxlength="2" value="<?php echo @$dataquery['keputusan']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Kepanjangan</td>
    <td width="2%">:</td>
    <td width="82%"><input name="nama" type="text" size="50" maxlength="50" value="<?php echo @$dataquery['nama']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Nilai Awal</td>
    <td width="2%">:</td>
    <td width="82%"><input name="t1" type="number" size="10" maxlength="4" value="<?php echo @$dataquery['t1']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Nilai Tengah</td>
    <td width="2%">:</td>
    <td width="82%"><input name="t2" type="number" size="10" maxlength="4" value="<?php echo @$dataquery['t2']; ?>" class="required"></td>
  </tr>
  <tr>
    <td width="16%">Nilai Akhir</td>
    <td width="2%">:</td>
    <td width="82%"><input name="t3" type="number" size="10" maxlength="4" value="<?php echo @$dataquery['t3']; ?>" class="required"></td>
  </tr>
  <tr>
    <td colspan="3"><input name="simpan" type="submit" value="Simpan" class="ok"></td>
  </tr>
</table>
</form>