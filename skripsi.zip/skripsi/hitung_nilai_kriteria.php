<h3>Perhitungan Bobot Kriteria</h3>
<?php 
$qb="SELECT id_responden, responden, keterangan, tanggal FROM ft_responden ORDER BY id_responden ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<!-- TABEL KE-1 -->
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="45" rowspan="2">Kode</td>
    <td width="684" rowspan="2">Kriteria</td>
    <td colspan="<?php echo $jmlkkolom; ?>"><div style="text-align:center;">Pilihan Bobot</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="403"><div style="text-align:center;"><?php echo "$db[responden]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[kriteria]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_responden, responden, keterangan, tanggal FROM ft_responden ORDER BY id_responden ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_kriteria, bobot FROM ft_nilai_kriteria WHERE id_responden='$db2[id_responden]' and id_kriteria='$dquery_dinilai[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		?>
        <td style="text-align:center;"><?php echo $dn['bobot']; ?></td>
    <?php } ?>
    </tr>
<?php } ?>
</table>

<!-- TABEL KE-2 -->
<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Nilai Triangular Fuzzy Number</h4>
<?php
$qb="SELECT id_responden, responden, keterangan, tanggal FROM ft_responden ORDER BY id_responden ASC";
$hb=$koneksi->query($qb);
$jmlkkolom=mysqli_num_rows($hb);
?>
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="38" rowspan="2">Kode</td>
    <td width="278" rowspan="2">Kriteria</td>
    <td colspan="<?php echo $jmlkkolom*3; ?>"><div style="text-align:center;">Triangular Fuzzy Number</div></td>
    </tr>
  <tr>
    <?php 
		while($db=mysqli_fetch_array($hb)){
	?>
    <td width="816" colspan="3"><div style="text-align:center;"><?php echo "$db[responden]"; ?></div></td>
    <?php } ?>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[kriteria]"; ?></td>
    <?php
		$urut=0;
		$qb2="SELECT id_responden, responden, keterangan, tanggal FROM ft_responden ORDER BY id_responden ASC";
		$hb2=$koneksi->query($qb2);
		while($db2=mysqli_fetch_array($hb2)){
			$urut=$urut+1;
    
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_kriteria, bobot, t1, t2, t3 FROM ft_nilai_kriteria WHERE id_responden='$db2[id_responden]' and id_kriteria='$dquery_dinilai[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		for($i=1; $i<=3; $i++) {
		?>
        <td style="text-align:center;"><?php echo $dn['t'.$i]; ?></td>
    <?php }} ?>
    </tr>
<?php } ?>
</table>

<!-- TABEL KE-3 -->
<?php
//Mulai Hitung Fuzzy Bobot
$query_dinilai="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	//Jumlah Responden
	$q_res="SELECT COUNT(*) FROM ft_responden ORDER BY id_responden ASC";
	$h_res=$koneksi->query($q_res);
	$d_res=mysqli_fetch_array($h_res);
	//Jumlah Nilai
	$q_nilai_a=mysqli_fetch_array($koneksi->query("SELECT SUM(t1) as jumlah_a FROM ft_nilai_kriteria WHERE id_kriteria='$dquery_dinilai[id_kriteria]'"));
	$q_nilai_b=mysqli_fetch_array($koneksi->query("SELECT SUM(t2) as jumlah_b FROM ft_nilai_kriteria WHERE id_kriteria='$dquery_dinilai[id_kriteria]'"));
	$q_nilai_c=mysqli_fetch_array($koneksi->query("SELECT SUM(t3) as jumlah_c FROM ft_nilai_kriteria WHERE id_kriteria='$dquery_dinilai[id_kriteria]'"));
	//Rata-rata
	$rata_a=$q_nilai_a['jumlah_a']/$d_res[0];
	$rata_b=$q_nilai_b['jumlah_b']/$d_res[0];
	$rata_c=$q_nilai_c['jumlah_c']/$d_res[0];

	$d_cek=mysqli_fetch_array($koneksi->query("SELECT COUNT(*) FROM ft_nilai_kriteria_hasil WHERE id_kriteria='$dquery_dinilai[id_kriteria]'"));
	if($d_cek[0]==0) {
		$koneksi->query("INSERT INTO ft_nilai_kriteria_hasil (id_kriteria, n_a, n_b, n_c) 
		         VALUES ('$dquery_dinilai[id_kriteria]', '$rata_a', '$rata_b', '$rata_c')");
	} else {
		$koneksi->query("UPDATE ft_nilai_kriteria_hasil SET n_a='$rata_a', n_b='$rata_b', n_c='$rata_c' 
		         WHERE id_kriteria='$dquery_dinilai[id_kriteria]'");
	}
}
?>

<h4 style="font-size:14px; margin:20px 0 10px 0; padding-bottom:5px; border-bottom:1px solid #D8D8D8;">Fuzzy Bobot Kriteria</h4>
<table width="100%" border="0" cellspacing="0" cellpadding="4">
  <tr>
    <td width="24" rowspan="2">No.</td>
    <td width="48" rowspan="2">Kode</td>
    <td width="475" rowspan="2">Kriteria</td>
    <td colspan="3"><div style="text-align:center;">Fuzzy Bobot</div></td>
    </tr>
  <tr>
    <td width="175"><div style="text-align:center;">a</div></td>
    <td width="199"><div style="text-align:center;">b</div></td>
    <td width="219"><div style="text-align:center;">c</div></td>
  </tr>
  
<?php
$no=0;

$query_dinilai="SELECT id_kriteria, kode, kriteria FROM ft_kriteria ORDER BY id_kriteria ASC";
$hquery_dinilai=$koneksi->query($query_dinilai);
while ($dquery_dinilai=mysqli_fetch_array($hquery_dinilai)){
	$no=$no+1;
?>
  <tr>
    <td><?php echo"$no"; ?></td>
    <td><?php echo"$dquery_dinilai[kode]"; ?></td>
    <td><?php echo"$dquery_dinilai[kriteria]"; ?></td>
    <?php
		//Ambil Nilai yang sudah disimpan (lalu tampilkan)
		$qn="SELECT id_nilai_kriteria_hasil, id_kriteria, n_a, n_b, n_c FROM ft_nilai_kriteria_hasil WHERE id_kriteria='$dquery_dinilai[id_kriteria]'";
		$hn=$koneksi->query($qn);
		$dn=mysqli_fetch_array($hn);
		?>
        <td style="text-align:center;"><?php echo number_format($dn['n_a'],4,',','.'); ?></td>
        <td style="text-align:center;"><?php echo number_format($dn['n_b'],4,',','.'); ?></td>
        <td style="text-align:center;"><?php echo number_format($dn['n_c'],4,',','.'); ?></td>
    </tr>
<?php } ?>
</table>